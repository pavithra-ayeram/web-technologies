function Footer() {
  return (
    <footer style={{ marginTop: "20px" }}>
      <p>© 2025 Pav’s Portfolio</p>
    </footer>
  );
}

export default Footer;
